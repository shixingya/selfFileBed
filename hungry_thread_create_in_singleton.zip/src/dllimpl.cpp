﻿#include "dllImpl.h"
DLL_IMPL DLL_IMPLSingleton::s_impl_;

DLL_IMPL_Ptr DLL_IMPLSingleton::get() {
	DLL_IMPL_Ptr ptr = &DLL_IMPLSingleton::s_impl_;
	return ptr;
}