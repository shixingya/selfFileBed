#include <iostream>
#include "dllimpl.h"

int main(int argc, char* argv[]){
	std::cout << " in main thread " << std::endl << std::flush;
	DLL_IMPL imp;
    std::cout <<"main thread "<<std::endl<<  std::flush;
    getchar();
    return 0;
}
