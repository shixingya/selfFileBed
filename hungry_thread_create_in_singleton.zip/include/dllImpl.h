#ifndef DLL_IMPL_H
#define DLL_IMPL_H
#include <iostream>
#include <mutex>
#include <thread>

#ifndef XTHREADPOOL_DLL
# ifdef _WIN32
#  if defined( BUILD_DLL )
#    define XTHREADPOOL_DLL __declspec(dllexport)
#  elif defined( USE_DLL )
#    define XTHREADPOOL_DLL __declspec(dllimport)
#  else
#    define XTHREADPOOL_DLL
#  endif
# else
#  define XTHREADPOOL_DLL
# endif
#endif

class XTHREADPOOL_DLL DLL_IMPL {
public:
	DLL_IMPL() {
		std::cout << __FUNCTION__ << " begin create subThread." << std::endl;
		std::thread t1([]() {
			std::cout << "subThread : Hello World" << std::endl;
		});
		t1.join();
		std::cout << __FUNCTION__ << " out" << std::endl;
	}
};
using DLL_IMPL_Ptr = DLL_IMPL * ;
class XTHREADPOOL_DLL DLL_IMPLSingleton {
public:
	static DLL_IMPL_Ptr get();
private:
	static DLL_IMPL s_impl_;
};
#endif